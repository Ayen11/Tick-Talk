
## ***Tick interval:***
You can set how fast an actor/component will tick with tick interval. You can't set it to a value smaller than delta time 'cause then it will just tick with FPS when you set the value too low, unlike timers with `Max Once Per Frame` turned off. 
When setting a new tick interval during run time your tick interval will only update on the next tick.
Setting the tick interval to 0 will make the actor/component tick every frame (default).

(when I say component I mean *actor* component here)

According to this source, if you try to shorten the tick interval during runtime it's recommended to disable tick, shorten the interval and activate it again to prevent waiting for the next tick? I'm not sure about this info tbh and IMO if you get to this scenario you should probably rethink the way you do things.
https://forums.unrealengine.com/t/changing-actor-tick-interval-while-running/331964/7?u=heyoletsgo9

https://www.youtube.com/watch?v=Axz20Fj_Kp8
https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/GameFramework/AActor/SetActorTickInterval

Another source for this chapter, but this one has a lot more details, would be worth reading thru all of this. This also covers Task Graphs! (and is outdated about the physics tick 😭)
https://www.casualdistractiongames.com/post/2018/12/10/unreal-tick-functions-delta-time-and-the-task-graph


### ***Tick interval vs timer:***
Timers will tick even when the actor's tick is disabled in class defaults. Meaning if your actor shouldn't tick all the time you can just disable tick and use a timer with the interval you wanted instead.
https://www.youtube.com/watch?v=T9Kzq4SvrAA

Recommended here that you should use timers instead of tick interval, and if you don't need your actor to tick all the time it's better to just use timers (timers tick even if the actor's tick is disabled). 
*Take this with a grain of salt as this links to the forum discussion I found this info at, no official sources, though it does make sense...*
https://forums.unrealengine.com/t/tick-interval-and-performance/150254/2

#### ***Timers over tick:***
> Timers have several benefits over Tick.
> 
> They can skip condition checks when not needed as one class keeps track of all timers running.
> 
> All timers are listed in a sorted list so they will always be executed in the same order unlike Ticking Actors in the same group.

> Use Tick for ticking every frame with or without interruptions.
> 
> Use Timers for everything else.
https://www.reddit.com/r/unrealengine/comments/gtxy6j/tickinterval_vs_timer/
Do note that timers are called after post physics so movement should still be on tick (without interval!).


![[ComapringTickvsTimelinevsTimer.webp]]
https://gameinspired-mail.medium.com/ue4-ticks-timelines-and-timers-9c7333952331

Tick (even with interval) has a greater performance cost even when it's not called, unlike timers and timeline that can be deactivated.

### ***Conclusion?*** 
Tick interval works like timers but you can set it's tick group.
Generally if you want something to loop not on frame (aka custom tick interval), the tick group becomes meaningless as you lose the accuracy you want either way. (I didn't find anything that says tick interval is better than a timer. I did find usage where they mix both options (link below) but tick interval could still be replaced with a second timer instead).

So, my conclusion is that tick interval is a cool option to make things tick less often and save some performance. But if you want to have better control and performance, just turn off ticking in the class defaults and use multiple timers as they give greater control *when* a class should tick and how often (you can also avoid bursting with timers since UE5.4), (and avoid going any lower than 0.1 - 0.05 as that's the average delta time).

(this is the link below)
https://www.cbgamedev.com/blog/quick-dev-tip-74-ue4-ue5-optimising-tick-rate


## ***Timelines and timers, extra info***

Timelines are **actor components**, you can find them as variables in the component section in BP. Since they're components they have independent tick than the owning actor. Meaning they tick normally even when the actor's tick is disabled and when there's a tick interval on the owning actor.

Since timelines are components, you can set them to tick when paused or set a tick interval for them. You can do that by dragging the timeline component reference variable and set it's setting like you would for any other component.

(the source for this section is me experimenting with the engine)

Timers on the other hand will not run when the game is paused. However they are still independent from the owning actor as they are part of `FTimerManager` and owning actor's tick interval will not affect them.

https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-timers-in-unreal-engine

## ***Advanced Tick() Functionality: Tickables & Multi-Tick (Extra)***

Multi tick and stuff. You can make non component/actors tick and they'll tick after TG_PostUpdate.
https://dev.epicgames.com/community/learning/tutorials/D7P8/unreal-engine-advanced-tick-functionality-tickables-multi-tick


what is FPS drops category?
what is Music Playback Percent?

| Type                          | Affected by Time Dilation | Affected by FPS                                  | Affected By Pause Game | FPS drops? | Notes                                                                                                                                                                                |
| ----------------------------- | ------------------------- | ------------------------------------------------ | ---------------------- | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Event Tick                    | yes                       | yes                                              | can be set not to      |            | Can use delta time to offset FPS. Can be set to run while paused.                                                                                                                    |
| Gameplay Timer                | yes                       | yes if interval time is lower than delta time    | yes                    |            | Can't be set to an interval lower than delta time.                                                                                                                                   |
| Timeline                      | yes                       | yes                                              | can be set not to      |            | Can be set to run while paused and set with a custom tick interval.                                                                                                                  |
| Audio Time                    | no                        | no                                               | yes                    |            | TBH IDK why it's called audio time.<br>Returns time in seconds since world was brought up for play, IS stopped when game pauses, NOT dilated/clamped.                                |
| Game Time                     | yes                       | no                                               | yes                    |            | Returns time in seconds since world was brought up for play.                                                                                                                         |
| Real Time In Seconds          | no                        | not really. see note in accurate real time below | no                     |            | Returns time in seconds since world was brought up for play, does NOT stop when game pauses, NOT dilated/clamped.                                                                    |
| Accurate Real Time In Seconds | no                        | no                                               | no                     |            | Returns time in seconds since the application was started. Unlike the other time functions this is accurate to the exact time this function is called instead of set once per frame. |
| Unpaused Time                 | yes                       | no                                               | no                     |            | Returns time in seconds since world was brought up for play, adjusted by time dilation and IS NOT stopped when game pauses.                                                          |
| Music Playback Percent        |                           |                                                  |                        |            |                                                                                                                                                                                      |
| Now                           | no                        | no                                               | no                     |            | Was called Current OS Time previously?<br>Returns the time from the computer as integer struct.                                                                                      |
